#include <iostream>
#include <pcl/ModelCoefficients.h>
#include <pcl/common/transformation_from_correspondences.h>
#include <pcl/common/transforms.h>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/passthrough.h>
#include <cmath>
#include <stdlib.h>
#include <stdio.h>
#include <limits>
#include <fstream>
#include <vector>
#include <Eigen/Core>
#include <pcl/point_cloud.h>
#include <pcl/registration/ia_ransac.h>
#include <Eigen/Dense>
#include <Eigen/Geometry>
using namespace std;    
using namespace Eigen;  
using namespace cv;

void findAvgAround(Mat* vols,int i,int j, double* avgs);

#define PI 3.14159

int main (int argc, char** argv)
{
//////////////////////////////////////////////
// Define Path to point cloud of terrain (ROI)
	const char* pcd_path = "../data/liveCloud_new.pcd";
	if(argc<1)
		cout<<"Assuming path to the terrain cloud's ROI: "<<pcd_path<<endl;
	else
		pcd_path = argv[1];
//////////////////////////////////////////////

	cout<<pcd_path<<endl;
//////////////////////////////////////////////
// Define cloud, read
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
	pcl::io::loadPCDFile (pcd_path, *cloud);
	std::cerr << "Point cloud data has: " << cloud->points.size () << " points" << std::endl;
	
// Find cuboid dimensions enclosing the cloud
	double min_x=cloud->points[0].x;
	double min_y=cloud->points[0].y;
	double max_x=cloud->points[0].x;
	double max_y=cloud->points[0].y;
	double depth_limit=cloud->points[0].z;
	for (size_t i = 0; i < cloud->points.size (); ++i)
	{
		if(min_x>cloud->points[i].x)
			min_x = cloud->points[i].x;
		if(min_y>cloud->points[i].y)
			min_y = cloud->points[i].y;
		if(max_x<cloud->points[i].x)
			max_x = cloud->points[i].x;
		if(max_y<cloud->points[i].y)
			max_y = cloud->points[i].y;
		if(fabs(depth_limit)<fabs(cloud->points[i].z))
			depth_limit = cloud->points[i].z;
	}
	double width=fabs(max_x-min_x);
	double height=fabs(max_y-min_y);
	cout<<"min_x: "<<min_x<<endl;
	cout<<"max_x: "<<max_x<<endl;
	cout<<"min_y: "<<min_y<<endl;
	cout<<"max_y: "<<max_y<<endl;
	cout<<"max_z: "<<depth_limit<<endl;

	//cout<<"Width : "<<width<<"\nHeight : "<<height<<"\nDepth : "<<depth_limit<<endl;

// Define grid size <= 5x5 cm: for each square (i.e. on xy-plane) you have a set of confined 3D points with varying z
//	double grid_w = 5;	// 5cm 
//	double grid_h = 5;	// 5cm 
		double grid_w;
		cout<<"Enter cell length (cm) (along x): ";cin>>grid_w;
		double grid_h;
		cout<<"Enter cell height (cm) (along y): ";cin>>grid_h;
		double ran_thr;
		cout<<"Enter RANSAC distance threshold for plane-fitting(cm): ";cin>>ran_thr;
		

/*	MatrixXd Xs(ceil(height/grid_h),ceil(width/grid_w));
	MatrixXd Ys(ceil(height/grid_h),ceil(width/grid_w));
	MatrixXd Zs(ceil(height/grid_h),ceil(width/grid_w));
	MatrixXd NorXs(ceil(height/grid_h),ceil(width/grid_w));
	MatrixXd NorYs(ceil(height/grid_h),ceil(width/grid_w));
	MatrixXd NorZs(ceil(height/grid_h),ceil(width/grid_w));
*/	
	int rows = ceil(height/grid_h);
	int cols = ceil(width/grid_w);

	cout<< "........................\nTotal rows (y-axis) of grid cells matrix: "<<rows<<endl;
	cout<< "Total columns (x-axis) of grid cells matrix: "<<cols<<endl;
/*	MatrixXd Xs(rows,cols);
	MatrixXd Ys(rows,cols);
	MatrixXd Zs(rows,cols);
	MatrixXd NorXs(rows,cols);
	MatrixXd NorYs(rows,cols);
	MatrixXd NorZs(rows,cols);*/
	int sizes[] = { rows, cols, 6 };
	cv::Mat *matr = new cv::Mat(3, sizes, CV_64FC1, cv::Scalar(0));

	//cout<<"Square Size: "<<grid_w<<" "<<grid_h<<" cm"<<endl;
//	NOTE: The point (0,0,z) is top left corner of the normal image. x increase left to right and y top to bottom

	pcl::PassThrough<pcl::PointXYZ> pass;
	pass.setInputCloud (cloud);

//	Set PassThrough filter for 3D Rasterizing, a pointCloud Raster (box) and then start the planning-operation
	
	pcl::PointCloud<pcl::PointXYZ>::Ptr rect(new pcl::PointCloud<pcl::PointXYZ>);
	pcl::PointCloud<pcl::PointXYZ>::Ptr box(new pcl::PointCloud<pcl::PointXYZ>);

cout<<"*************************************\n";
cout<< "Note: the plane fitting and thus indexing starts at (min_x,min_y) values of the cloud\n";
cout<<"*************************************\n";

	int totalMissingGridCells=0;		// # of cells that used previous plane and z values
	
	double center_x = 0;
	double center_y = 0;
	double center_z = -1;	// init
	Vector3f nor(0,0,0);

	for(int x=0; x<ceil(width/grid_w); x++)
	{
		pass.setFilterFieldName ("x");
		pass.setFilterLimits ( x * grid_w + min_x , ( x + 1 ) * grid_w + min_x);
		pass.setInputCloud (cloud);
		pass.filter (*rect);
		for(int y=0; y<ceil(height/grid_h); y++)
		{
			pass.setFilterFieldName ("y");
			pass.setFilterLimits ( y * grid_h + min_y , ( y + 1 ) * grid_h + min_y);
			pass.setInputCloud (rect);
			pass.filter (*box);
			
			center_x = ( ( x + 1 ) * grid_w + min_x + x * grid_w + min_x )/2;
			center_y = ( ( y + 1 ) * grid_h + min_y + y * grid_h + min_y )/2;

				center_z = -1;
				nor(0) = 0;
				nor(1) = 0;
				nor(2) = 0;

//	Fit planes (RANSAC)		
			if(box->points.size() >=3)
			{
				// PLANAR APPROXIMATION	 
				pcl::ModelCoefficients::Ptr coeff (new pcl::ModelCoefficients);
				pcl::PointIndices::Ptr inliers (new pcl::PointIndices);
				// Create the segmentation object
				pcl::SACSegmentation<pcl::PointXYZ> seg;
				// Optional
				seg.setOptimizeCoefficients (true);
				// Mandatory
				seg.setModelType (pcl::SACMODEL_PLANE);
				seg.setMethodType (pcl::SAC_RANSAC);
				seg.setDistanceThreshold (ran_thr);//0.01 originally
				// Fit
				seg.setInputCloud (box->makeShared ());
				seg.segment (*inliers, *coeff);
	
				if (inliers->indices.size () == 0)
				{
					PCL_ERROR ("Could not estimate a planar model of ROI cloud for the given dataset.");
					cout<<endl;
					totalMissingGridCells++;
				}
				else
				{

	/*			std::cerr << "Model coefficients Reference: " << coeff_ref->values[0] << " " 
									      << coeff_ref->values[1] << " "
									      << coeff_ref->values[2] << " " 
									      << coeff_ref->values[3] << std::endl;
				std::cerr << "Model coefficients Target: " << coeff_tar->values[0] << " " 
								    	   << coeff_tar->values[1] << " "
									   << coeff_tar->values[2] << " " 
									   << coeff_tar->values[3] << std::endl;
	*/
					// finding z = (-ax -by -d) / c
					center_z = (-(coeff->values[0])*center_x -(coeff->values[1])*center_y -(coeff->values[3]))/ (coeff->values[2]);

					////////////////////////////////
					// Code that Furqan has to write!
					// Assign the following to (y,x) location of a matrix
					// mat(y,x)=(center_x,center_y,center_z,coeff->values[0],coeff->values[1],coeff->values[2]);

					nor(0) = coeff->values[0];
					nor(1) = coeff->values[1];
					nor(2) = coeff->values[2];
					nor = nor.normalized();
				}

			}
			matr->at<double>(y,x,0)=center_x;
			matr->at<double>(y,x,1)=center_y;
			// may use previous z-values
			matr->at<double>(y,x,2)=center_z;	
			matr->at<double>(y,x,3)=nor(0);
			matr->at<double>(y,x,4)=-nor(1);
			matr->at<double>(y,x,5)=-nor(2);	// flip vector
		}
	}
// To account for missing grids
/*	int zes[] = { rows, cols, 4 };
	cv::Mat *mask_matr = new cv::Mat(3, zes, CV_64FC1, cv::Scalar(0));
	double* avgs;
	for(int i=0;i<ceil(height/grid_h);i++)
	{
		for(int j=0;j<ceil(width/grid_w);j++)
		{
			if(matr->at<double>(i,j,2)==-1)
			{
// Create a second 3D matrix of same size that will store corresponding average values for missing cells
				findAvgAround(matr,i,j,avgs);
				cout<<avgs[0];
				mask_matr->at<double>(i,j,0)= avgs[0];	// Puts the average value of center_z found using neighbors, at current grid 
				mask_matr->at<double>(i,j,1)= avgs[1];	// Puts the average value of center_z found using neighbors, at current grid 
				mask_matr->at<double>(i,j,2)= avgs[2];	// Puts the average value of center_z found using neighbors, at current grid 
				mask_matr->at<double>(i,j,3)= avgs[3];	// Puts the average value of center_z found using neighbors, at current grid 
				cout<< "Averaging at: ("<<i<<","<<j<<") i.e. in real-coords: ("<<matr->at<double>(i,j,0)<<","<<matr->at<double>(i,j,1)<<")"<<endl;
			}
		}
	}

// Fill in old matrix
	for(int i=0;i<ceil(height/grid_h);i++)
	{
		for(int j=0;j<ceil(width/grid_w);j++)
		{
			if(matr->at<double>(i,j,2)==-1)
			{
				matr->at<double>(i,j,2) = mask_matr->at<double>(i,j,0);
				matr->at<double>(i,j,3) = mask_matr->at<double>(i,j,1);
				matr->at<double>(i,j,4) = mask_matr->at<double>(i,j,2);
				matr->at<double>(i,j,5) = mask_matr->at<double>(i,j,3);
			}
		}
	}
*/
	/*int zes[]={2,3,4};
	cv::Mat *matrix = new cv::Mat(3, zes, CV_32FC1, cv::Scalar(0));
	matrix->at<float>(0,0,0)=1;
	matrix->at<float>(0,0,1)=2;
	matrix->at<float>(0,0,2)=3;
	matrix->at<float>(0,0,3)=4;
	matrix->at<float>(0,1,0)=20;
	matrix->at<float>(0,1,1)=21;
	matrix->at<float>(0,1,2)=22;*/
  cv::FileStorage fs("../data/motionPlan.yml", CV_STORAGE_WRITE);
  if( fs.isOpened() )
  {
			
//      fs << "Xs" << Xs << "Ys" << Ys << "Zs" << Zs << "NorXs" << NorXs << "NorYs" << NorYs << "NorZs" << NorZs;
	cout<<"Writing to file ../data/motionPlan.yml"<<endl;
			fs<<"Planes"<<*matr;//<<"Tester"<<*matrix;
      fs.release();
  }
	cout<<"Missing grid cells: "<<totalMissingGridCells<<endl;

	return (0);
}


// Following has unexplained issues
void findAvgAround(Mat* vols,int i,int j, double* avgs)
{
	// This function finds the average volume around raster (i,j) in vols, it searches around increasing radius till threshold
	// (i,j) is raster location. ith row, jth col
	double avgZ=vols->at<double>(i, j, 2);
	double avgNX=vols->at<double>(i, j, 3);
	double avgNY=vols->at<double>(i, j, 4);
	double avgNZ=vols->at<double>(i, j, 5);
	int k=0;
	vector<double> decZ;
	vector<double> decNX;
	vector<double> decNY;
	vector<double> decNZ;
	decZ.clear();
	decNX.clear();
	decNY.clear();
	decNZ.clear();

	int k_i[2]={i-k,i+k};
	int k_j[2]={j-k,j+k};

	while(avgZ<0)
	{
		k++;
		k_i[0]=i-k;
		k_j[0]=j-k;
		k_i[1]=i+k;
		k_j[1]=j+k;
		if(k_i[0]<0)
			k_i[0]=0;
		if(k_i[1]>=vols->rows)
			k_i[1]=vols->rows-1;
		if(k_j[0]<0)
			k_j[0]=0;
		if(k_j[1]>=vols->cols)
			k_j[1]=vols->cols-1;

//		vol=(*vols)(Rect(k_j[0],k_i[0],k_j[1]-k_j[0],k_i[1]-k_i[0]));

		for(int p=k_i[0];p<=k_i[1];p++)
			for(int q=k_j[0];q<=k_j[1];q++)
				if(vols->at<double>(p,q,2)>0){
					decZ.push_back(vols->at<double>(p,q, 2));
					decNX.push_back(vols->at<double>(p,q, 3));
					decNY.push_back(vols->at<double>(p,q, 4));
					decNZ.push_back(vols->at<double>(p,q, 5));
				}
//		cout<<vol.at<double>(p,q)<<endl;}
		avgZ=(double)mean(decZ)[0];
		avgNX=(double)mean(decNX)[0];
		avgNY=(double)mean(decNY)[0];
		avgNZ=(double)mean(decNZ)[0];
	}
//	double out[]={avgZ,avgNX,avgNY,avgNZ};
//	return out;
		cout<<avgZ;
	avgs[0] = avgZ;
	avgs[1] = avgNX;
	avgs[2] = avgNY;
	avgs[3] = avgNZ;
}
