#include <iostream>
#include <pcl/ModelCoefficients.h>
#include <pcl/point_types.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <iostream>
#include <pcl/io/io.h>
#include <pcl/io/pcd_io.h>
#include <cmath>
#include <stdlib.h>
#include <stdio.h>
#include <pcl/sample_consensus/mlesac.h>
using namespace std;    

int
 main (int argc, char *argv[])
{
	//take the index of the pcd you want to planar segment the cloud of
	if(argc<2)
	{
		cout<<"please enter pcd_path"<<endl;
		return 0;
	}

    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
    pcl::io::loadPCDFile (argv[1], *cloud);

	std::cerr << "Point cloud data: " << cloud->points.size () << " points" << std::endl;
	 
	pcl::ModelCoefficients::Ptr coefficients (new pcl::ModelCoefficients);
	pcl::PointIndices::Ptr inliers (new pcl::PointIndices);
	// Create the segmentation object
	pcl::SACSegmentation<pcl::PointXYZ> seg;
	// Optional
	seg.setOptimizeCoefficients (true);
	// Mandatory
	seg.setModelType (pcl::SACMODEL_PLANE);
	seg.setMethodType (pcl::SAC_RANSAC);
	seg.setDistanceThreshold (1);//0.01 originally

	seg.setInputCloud (cloud->makeShared ());
	seg.segment (*inliers, *coefficients);

	if (inliers->indices.size () == 0)
	{
		PCL_ERROR ("Could not estimate a planar model for the given dataset.");
		return (-1);
	}

	std::cerr << "Model coefficients: " << coefficients->values[0] << " " 
		                              << coefficients->values[1] << " "
		                              << coefficients->values[2] << " " 
		                              << coefficients->values[3] << std::endl;

	//save empty bucket's plane eq
			std::ofstream fout;
			fout.open("EmptyPlaneEq.txt");
			if(fout.fail( ) )
			{ 
				cout << "Error. Could not save to file.\n\n\n";
			}
			else
			{
				fout<<coefficients->values[0]<<endl<<coefficients->values[1]<<endl<<coefficients->values[2]<<endl<<coefficients->values[3];
			}
			fout.close();
		cout<<"Eq of plane successfully written\n";

// Finding min and max along x and y dims of the cloud
	double min_x=cloud->points[0].x;
	double min_y=cloud->points[0].y;
	double max_x=cloud->points[0].x;
	double max_y=cloud->points[0].y;
	for (size_t i = 0; i < cloud->points.size (); ++i)
	{
		if(min_x>cloud->points[i].x)
			min_x = cloud->points[i].x;
		if(min_y>cloud->points[i].y)
			min_y = cloud->points[i].y;
		if(max_x<cloud->points[i].x)
			max_x = cloud->points[i].x;
		if(max_y<cloud->points[i].y)
			max_y = cloud->points[i].y;
	}
	double width=max_x-min_x;
	double height=max_y-min_y;
	cout<<"Distance between furthest points along x (width): "<<width<<endl<<"Distance between furthest points along y (height): "<<height<<endl;

// Finding the angle between camera plane and the plane fitted over the cloud
		

		std::ofstream fpcd;
		fpcd.open("../data/PointClouds/cloud_plane.pcd");
		fpcd<<"# .PCD v.5 - Point Cloud Data file format"<<endl;
		fpcd<<"FIELDS x y z"<<endl;
		fpcd<<"SIZE 4 4 4"<<endl;//8
		fpcd<<"TYPE F F F"<<endl;//D
		fpcd<<"WIDTH "<<10000<<endl;
		fpcd<<"HEIGHT 1"<<endl;
		fpcd<<"POINTS "<<10000<<endl;
		fpcd<<"DATA ascii";

		for (float x=-5;x<5;x=x+0.1)
		{
			for (float y=-5;y<5;y=y+0.1)
			{
				fpcd<<endl<<x<<" "<<y<<" "<<((-coefficients->values[0]*x)-(coefficients->values[1]*y)-(coefficients->values[3]))/coefficients->values[2];
			}
		}
		fpcd.close();

		std::ofstream fpcd2;
		fpcd2.open("../data/PointClouds/camera_plane.pcd");
		fpcd2<<"# .PCD v.5 - Point Cloud Data file format"<<endl;
		fpcd2<<"FIELDS x y z"<<endl;
		fpcd2<<"SIZE 4 4 4"<<endl;//8
		fpcd2<<"TYPE F F F"<<endl;//D
		fpcd2<<"WIDTH "<<10000<<endl;
		fpcd2<<"HEIGHT 1"<<endl;
		fpcd2<<"POINTS "<<10000<<endl;
		fpcd2<<"DATA ascii";

		for (float x=-5;x<5;x=x+0.1)
		{
			for (float y=-5;y<5;y=y+0.1)
			{
				fpcd2<<endl<<x<<" "<<y<<" "<<0;
			}
		}
		fpcd2.close();

		pcl::PointXYZ median;
		median.x = 0;
		median.y = 0;
		median.z = 0;
		for (size_t i = 0; i < cloud->points.size (); ++i)
		{
			median.x = median.x + cloud->points[i].x;
			median.y = median.y + cloud->points[i].y;
		}
		median.x = median.x/cloud->points.size ();
		median.y = median.y/cloud->points.size ();
		median.z = ((-coefficients->values[0]*median.x)-(coefficients->values[1]*median.y)-(coefficients->values[3]))/coefficients->values[2];
		
		cout<<"Centroid of cloud: "<<median<<endl;
		pcl::PointXYZ med;
		med.x = median.x + 65;
		med.y = median.y + 37.5;
		med.z = median.z - 41;
		cout<<"***************\nTranslated Centroid: "<<med<<endl;
		cout<<"Normal vector of cloud: ("<<coefficients->values[0]<<","<<coefficients->values[1]<<","<<coefficients->values[2]<<")\n";
	
			 
}

