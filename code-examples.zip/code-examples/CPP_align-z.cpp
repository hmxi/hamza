#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <cmath>

#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <Eigen/Core>

#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/common/transforms.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>

//#include <Eigen/Dense>
//#include <Eigen/Geometry>

using namespace std;    
using namespace Eigen;
using namespace cv;

#define PI 3.14159

int main (int argc, char** argv)
{
	if(argc<=4)
	{
		cout<<"Enter paths of the <cloud> <roi_cloud_floor> <roi_cloud_wall> <output_cloud>"<<endl;
		return 0;
	}

	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
	pcl::io::loadPCDFile (argv[1], *cloud);

	pcl::PointCloud<pcl::PointXYZ>::Ptr roi_cloud (new pcl::PointCloud<pcl::PointXYZ>);
	pcl::io::loadPCDFile (argv[2], *roi_cloud);

	pcl::PointCloud<pcl::PointXYZ>::Ptr roi_cloud_wall (new pcl::PointCloud<pcl::PointXYZ>);
	pcl::io::loadPCDFile (argv[3], *roi_cloud_wall);

	std::cerr << "Point cloud data: " << cloud->points.size () << " points" << std::endl;
	std::cerr << "Point cloud data: " << roi_cloud->points.size () << " points" << std::endl;
	std::cerr << "Point cloud data: " << roi_cloud_wall->points.size () << " points" << std::endl;
	 
// Fit plane to the roi_cloud
	pcl::ModelCoefficients::Ptr coefficients (new pcl::ModelCoefficients);
	pcl::ModelCoefficients::Ptr coefficients_wall (new pcl::ModelCoefficients);
	pcl::PointIndices::Ptr inliers (new pcl::PointIndices);
	pcl::PointIndices::Ptr inliers_wall (new pcl::PointIndices);
	// Create the segmentation object
	pcl::SACSegmentation<pcl::PointXYZ> seg;
	pcl::SACSegmentation<pcl::PointXYZ> seg_wall;
	// Optional
	seg.setOptimizeCoefficients (true);
	seg_wall.setOptimizeCoefficients (true);
	// Mandatory
	seg.setModelType (pcl::SACMODEL_PLANE);
	seg.setMethodType (pcl::SAC_RANSAC);
	seg.setDistanceThreshold (1);//i.e. 1cm as the cloud is in cm
	seg_wall.setModelType (pcl::SACMODEL_PLANE);
	seg_wall.setMethodType (pcl::SAC_RANSAC);
	seg_wall.setDistanceThreshold (1);//i.e. 1cm as the cloud is in cm

	seg.setInputCloud (roi_cloud->makeShared ());
	seg.segment (*inliers, *coefficients);
	seg_wall.setInputCloud (roi_cloud_wall->makeShared ());
	seg_wall.segment (*inliers_wall, *coefficients_wall);

	if (inliers->indices.size () == 0)
	{
		PCL_ERROR ("Could not estimate a planar model for the given dataset.");
		return (-1);
	}

	std::cerr << "Ground plane coefficients: " << coefficients->values[0] << " " 
		                              << coefficients->values[1] << " "
		                              << coefficients->values[2] << " " 
		                              << coefficients->values[3] << std::endl;

/*	seg.setInputCloud (roi_cloud_wall->makeShared ());
	seg.segment (*inliers_wall, *coefficients_wall);

	if (inliers->indices.size () == 0)
	{
		PCL_ERROR ("Could not estimate a planar model for the given dataset.");
		return (-1);
	}
*/
	std::cerr << "Wall plane coefficients: " << coefficients_wall->values[0] << " " 
		                              << coefficients_wall->values[1] << " "
		                              << coefficients_wall->values[2] << " " 
		                              << coefficients_wall->values[3] << std::endl;
	
// Estimate Transformation between normal of the roi_cloud plane, and camera z axis

	Vector3f roi_normal(coefficients->values[0], coefficients->values[1], coefficients->values[2]);
	Vector3f wall_normal(coefficients_wall->values[0], coefficients_wall->values[1], coefficients_wall->values[2]);
	Vector3f z_axis(0,0,1);
	Vector3f y_axis(0,1,0);

	Vector3f cprod;
	cprod = (roi_normal.cross(z_axis)).normalized();
//  float angle = acos(roi_normal.dot(z_axis)/norm(roi_normal));
	AngleAxisf AA(acos(roi_normal.dot(z_axis)/roi_normal.norm()), cprod);

	cout<<"Angle between camera z-axis and floor: "<<acos(roi_normal.dot(z_axis)/roi_normal.norm())*180/PI<<endl;
//	Transform<Affine> t(AngleAxis(M_PI,cprod));
	Transform<float,3,Affine> t(AA);

	pcl::PointCloud<pcl::PointXYZ> trans_floor;
	pcl::PointCloud<pcl::PointXYZ> transformed_cloud;
	pcl::transformPointCloud (*cloud, trans_floor, t);

// Now rotate to align wall

	wall_normal=t*wall_normal;	// Get the transformed normal vector of wall
	wall_normal(2)=0;

// We have the transformed wall_normal, now find the angle between this normal and your y-axis and rotate the cloud to align

	cout<<wall_normal<<endl;

	cprod = (wall_normal.cross(y_axis)).normalized();

	AngleAxisf AW(acos(wall_normal.dot(y_axis)/wall_normal.norm()), cprod);
	Transform<float,3,Affine> tW(AW);
	cout<<"Angle between camera y-axis and wall: "<<acos(wall_normal.dot(y_axis)/wall_normal.norm())*180/PI<<endl;

//	pcl::transformPointCloud (trans_floor, transformed_cloud, tW);
	pcl::transformPointCloud (*cloud, transformed_cloud, tW*t);	// Transform the whole cloud at once


	Transform<float,3,Affine> tra;
	tra=tW*t;

  cv::Mat *tra_cv = new cv::Mat(3, 3, CV_64F);

	std::cout<<"Transformation Matrix = "<<std::endl;
	for(int i=0;i<=2;i++)
	{	for(int j=0;j<=2;j++)
			cout<<tra(i,j)<<"   "<<std::endl;
	}
			tra_cv->at<double>(0,0) = tra(0,0);
			tra_cv->at<double>(0,1) = tra(0,1);
			tra_cv->at<double>(0,2) = tra(0,2);
			tra_cv->at<double>(1,0) = tra(1,0);
			tra_cv->at<double>(1,1) = tra(1,1);
			tra_cv->at<double>(1,2) = tra(1,2);
			tra_cv->at<double>(2,0) = tra(2,0);
			tra_cv->at<double>(2,1) = tra(2,1);
			tra_cv->at<double>(2,2) = tra(2,2);

	pcl::io::savePCDFileBinary (argv[4], transformed_cloud);

	cv::FileStorage fs("../data/transform_align.yml", CV_STORAGE_WRITE);
  if( fs.isOpened() )
  {
			fs<<"Trans"<<*tra_cv;//<<"Tester"<<*matrix;
      fs.release();
  }
	std::cout<<"\n../data/transform_align.yml created\n";
	

//	std::cout<<m<<std::endl;
//Matrix3f m;
//m = AngleAxisf(0.25*M_PI, Vector3f::UnitX()) * AngleAxisf(0.5*M_PI,  Vector3f::UnitY()) * AngleAxisf(0.33*M_PI, Vector3f::UnitZ());
//cout << m << endl << "is unitary: " << m.isUnitary() << endl;

//m = AngleAxisf(0.5*M_PI,  Vector3f::UnitY()) * AngleAxisf(0.25*M_PI, Vector3f::UnitX()) * AngleAxisf(0.33*M_PI, Vector3f::UnitZ());
//cout << m << endl << "is unitary: " << m.isUnitary() << endl;
//	return 0;

}

